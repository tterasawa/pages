# NotebookLM Audio Recorder (MP3)

- 現在のタブ音声を録音し、MP3（lamejs）で保存。lamejs が無い場合は WAV 保存。
- NotebookLM にそのままアップロード可能（MP3/WAV）。

## セットアップ

1. 本ファイル群をフォルダに配置
2. `vendor/lame.min.js` を配置（無ければ WAV）
3. `chrome://extensions` → デベロッパーモード → フォルダを読み込み

## 使い方

- YouTube などを再生
- 拡張アイコンまたは `Ctrl+Shift+Y` で開始/停止
- 停止後に保存ダイアログ
