// let isRecording = false; // ★ 削除：この変数は使いません

async function ensureOffscreen() {
  if (chrome.offscreen?.hasDocument && (await chrome.offscreen.hasDocument()))
    return;
  await chrome.offscreen.createDocument({
    url: chrome.runtime.getURL("offscreen.html"),
    reasons: ["USER_MEDIA", "BLOBS"],
    justification: "Start/stop recording and receive converted audio",
  });
}

async function startRecording(tabId) {
  if (!tabId) {
    console.error("Invalid tabId");
    return;
  }
  const tab = await chrome.tabs.get(tabId);
  await chrome.windows.update(tab.windowId, { focused: true });
  await chrome.tabs.update(tab.id, { active: true });

  await ensureOffscreen();

  // 起動中インジケータ
  chrome.action.setBadgeText({ text: "…" });
  chrome.action.setBadgeBackgroundColor({ color: "#777" });

  let streamId;
  try {
    streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: tab.id,
    });
  } catch (e) {
    console.error("Failed to get media stream ID:", e);
    chrome.action.setBadgeText({ text: "ERR" });
    chrome.action.setBadgeBackgroundColor({ color: "#f00" });
    // エラー時はバッジをすぐ消す
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2000);
    return;
  }

  chrome.runtime.sendMessage({
    type: "START_RECORDING",
    streamId: streamId,
  });
}

function stopRecording() {
  chrome.runtime.sendMessage({ type: "STOP_RECORDING" });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "STARTED") {
    // isRecording = true; // ★ 削除
    chrome.action.setBadgeText({ text: "REC" });
    chrome.action.setBadgeBackgroundColor({ color: "#d33" });
  }
  if (msg?.type === "FINALIZED") {
    // isRecording = false; // ★ 削除
    chrome.action.setBadgeText({ text: "" });

    (async () => {
      if (await chrome.offscreen.hasDocument()) {
        chrome.offscreen.closeDocument();
      }
    })();
  }

  // ... (ダウンロード処理は変更なし) ...
  if (msg?.type === "DOWNLOAD_FILE" && msg.url) {
    const name = `youtube-audio-${new Date()
      .toISOString()
      .replace(/[:.]/g, "-")}.${msg.ext}`;

    chrome.downloads.download(
      { url: msg.url, filename: name, saveAs: true },
      (downloadId) => {
        if (downloadId) {
          chrome.runtime.sendMessage(
            { type: "REVOKE_URL", url: msg.url },
            () => {
              if (chrome.runtime.lastError) {
                /* Offscreenが閉じていても無視 */
              }
            }
          );
        } else {
          console.warn("Download failed, revoking URL.");
          chrome.runtime.sendMessage(
            { type: "REVOKE_URL", url: msg.url },
            () => {
              if (chrome.runtime.lastError) {
                /* 同上 */
              }
            }
          );
        }
      }
    );
  }

  if (msg?.type === "VIDEO_ENDED") {
    console.log("Received VIDEO_ENDED from content script.");
    // 現在録音中かどうかをバッジテキストで確認
    (async () => {
      const currentBadge = await chrome.action.getBadgeText({});
      const isRecording = currentBadge === "REC";

      if (isRecording) {
        // 録音中であれば停止する
        console.log("Video ended, stopping recording.");
        stopRecording();
      }
    })();
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;

  // ★ 変更点：現在のバッジテキストを取得して状態を判断
  const currentBadge = await chrome.action.getBadgeText({});
  const isRecording = currentBadge === "REC";

  // "…" (起動中) の場合は何もしない
  if (currentBadge === "…") return;

  if (!isRecording) await startRecording(tab.id);
  else stopRecording();
});

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== "toggle-recording") return;
  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });
  if (!tab?.id) return;

  // ★ 変更点：現在のバッジテキストを取得して状態を判断
  const currentBadge = await chrome.action.getBadgeText({});
  const isRecording = currentBadge === "REC";

  // "…" (起動中) の場合は何もしない
  if (currentBadge === "…") return;

  if (!isRecording) await startRecording(tab.id);
  else stopRecording();
});
