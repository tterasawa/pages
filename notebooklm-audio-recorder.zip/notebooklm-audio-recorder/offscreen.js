let mediaRecorder;
let chunks = [];
let capturing = false;
let activeStream = null;
// let ac = null; // ★ 削除

function send(type, data = {}) {
  try {
    chrome.runtime.sendMessage({ type, ...data });
  } catch {}
}

async function startRecording(streamId) {
  if (capturing) return;
  try {
    activeStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
        },
      },
      video: false,
    });

    if (!activeStream) {
      console.error("getUserMedia returned null");
      send("FINALIZED");
      return;
    }

    chunks = [];

    // ★ 変更点：M4A(mp4) > WebM の優先順位で録音を試みる
    const supportedTypes = [
      { mimeType: "audio/mp4", ext: "m4a" }, // NotebookLMがサポート
      { mimeType: "audio/webm", ext: "webm" }, // フォールバック
    ];

    let selectedType = null;
    for (const type of supportedTypes) {
      if (MediaRecorder.isTypeSupported(type.mimeType)) {
        selectedType = type;
        break;
      }
    }

    if (!selectedType) {
      console.error("No supported mimeType found");
      send("FINALIZED");
      return;
    }

    console.log(`Recording with mimeType: ${selectedType.mimeType}`);
    mediaRecorder = new MediaRecorder(activeStream, {
      mimeType: selectedType.mimeType,
    });

    // mediaRecorder に拡張子を保存しておく
    // @ts-ignore
    mediaRecorder.fileExtension = selectedType.ext;

    mediaRecorder.onstart = () => send("STARTED");
    mediaRecorder.ondataavailable = (e) => e.data?.size && chunks.push(e.data);
    mediaRecorder.onerror = (e) => console.error("MediaRecorder error:", e);
    mediaRecorder.onstop = finalize;

    mediaRecorder.start(2000);
    capturing = true;
  } catch (e) {
    console.error("startRecording failed:", e);
    if (activeStream) {
      activeStream.getTracks().forEach((track) => track.stop());
      activeStream = null;
    }
    send("FINALIZED");
  }
}

function stopRecording() {
  if (mediaRecorder && capturing && mediaRecorder.state === "recording") {
    try {
      mediaRecorder.requestData();
      setTimeout(() => {
        try {
          mediaRecorder.stop();
        } catch {}
      }, 20);
    } catch (e) {
      console.warn("stopRecording error:", e);
      try {
        mediaRecorder.stop();
      } catch {}
    }
  }
}

// ★ 変更点： finalize を大幅に簡略化。JSでの変換をすべて削除
async function finalize() {
  try {
    if (!mediaRecorder) {
      throw new Error("MediaRecorder not found");
    }

    // @ts-ignore
    const ext = mediaRecorder.fileExtension || "webm";
    const mimeType = mediaRecorder.mimeType || "audio/webm";

    const finalBlob = new Blob(chunks, { type: mimeType });
    chunks = [];

    const url = URL.createObjectURL(finalBlob);
    send("DOWNLOAD_FILE", { url, ext });
  } catch (e) {
    console.error("finalize failed:", e);
  } finally {
    capturing = false;
    if (activeStream) {
      activeStream.getTracks().forEach((track) => track.stop());
      activeStream = null;
    }
    mediaRecorder = null;
    send("FINALIZED");
  }
}

// ---- ★ 削除：WAV/MP3 変換ユーティリティ ----
// floatTo16BitPCM, interleave, encodeWAV, importLame, encodeMP3WithLame, download
// 上記の関数をすべて削除します。

// メッセージ受信 (変更なし)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "START_RECORDING") {
    if (msg.streamId) {
      startRecording(msg.streamId);
    } else {
      console.error("START_RECORDING message received without streamId");
      send("FINALIZED");
    }
  }
  if (msg?.type === "STOP_RECORDING") stopRecording();

  if (msg?.type === "REVOKE_URL" && msg.url) {
    URL.revokeObjectURL(msg.url);
  }
});
