console.log("[Recorder] content.js が読み込まれました。 (v2: timeupdate)");

// 監視対象の<video>要素と、終了メッセージ送信済みフラグを保持
let observedVideoElement = null;
let hasSentEndMessage = false;

/**
 * 動画の終了を監視するリスナーをセットアップします。
 */
function setupVideoEndListener() {
  console.log("[Recorder] setupVideoEndListener が実行されました。");

  // ページ遷移や再セットアップ時にフラグをリセット
  hasSentEndMessage = false;

  // 既に古いリスナーが登録されていれば解除
  if (observedVideoElement) {
    observedVideoElement.removeEventListener("timeupdate", handleTimeUpdate);
    console.log('[Recorder] 古い "timeupdate" リスナーを解除しました。');
  }

  setTimeout(() => {
    const video = document.querySelector("video.html5-main-video");

    if (video) {
      console.log("[Recorder] <video> 要素を発見しました。", video);
      observedVideoElement = video; // 監視対象をグローバルに保持

      // ★ 変更点： 'ended' の代わりに 'timeupdate' を監視します
      // 'timeupdate' は再生中に1秒間に数回、継続的に呼び出されます
      video.addEventListener("timeupdate", handleTimeUpdate);

      console.log(
        '[Recorder] "timeupdate" (時間更新) リスナーを登録しました。'
      );
    } else {
      console.error("[Recorder] エラー: <video> 要素が見つかりませんでした。");
    }
  }, 1500); // 1.5秒待つ
}

/**
 * ★ 新しい関数：
 * 'timeupdate' イベントのたびに呼び出され、動画の終了を能動的にチェックします。
 */
function handleTimeUpdate() {
  // 既に終了メッセージを送信済みか、<video>要素がなければ何もしない
  if (hasSentEndMessage || !observedVideoElement) {
    return;
  }

  const video = observedVideoElement;
  const currentTime = video.currentTime; // 現在の再生時間
  const duration = video.duration; // 動画の総時間

  // duration が有効な数値 (NaNではない) で、
  // かつ再生時間が動画の総時間の「終了0.5秒前」に達したら
  if (duration && currentTime > 0 && currentTime >= duration - 0.5) {
    console.log(
      `[Recorder] "timeupdate" が終了を検知しました！ (Current: ${currentTime}, Duration: ${duration})`
    );

    // ★ 重要：一度だけ実行する
    hasSentEndMessage = true;

    // 念のため、この<video>要素からの 'timeupdate' 監視を停止
    if (observedVideoElement) {
      observedVideoElement.removeEventListener("timeupdate", handleTimeUpdate);
    }

    // background.js に「VIDEO_ENDED」というメッセージを送信
    sendEndMessage();
  }
}

/**
 * background.js にメッセージを送信する関数 (変更なし)
 */
function sendEndMessage() {
  console.log('[Recorder] "VIDEO_ENDED" メッセージの送信処理を開始します。');
  chrome.runtime.sendMessage({ type: "VIDEO_ENDED" });
  console.log('[Recorder] background.js に "VIDEO_ENDED" を送信しました。');
}

// 1. 初回読み込み時にリスナーをセットアップ
setupVideoEndListener();

// 2. YouTube内のページ遷移（別の動画に移った時）にも対応
document.addEventListener("yt-navigate-finish", () => {
  console.log(
    '[Recorder] "yt-navigate-finish" イベントを検知しました (ページ遷移)。'
  );
  // リスナーを再セットアップ
  setupVideoEndListener();
});
